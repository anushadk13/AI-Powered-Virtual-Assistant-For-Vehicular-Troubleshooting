<script>
	import Playground from '$lib/components/playground/Playground.svelte';
</script>

<Playground />
